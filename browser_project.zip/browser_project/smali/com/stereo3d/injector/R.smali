.class public final Lcom/stereo3d/injector/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/stereo3d/injector/R$attr;,
        Lcom/stereo3d/injector/R$drawable;,
        Lcom/stereo3d/injector/R$string;,
        Lcom/stereo3d/injector/R$style;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    .prologue
    .line 22
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    return-void
.end method
