.class Lcom/stereo3d/injector/MainActivity$100000001;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnTouchListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/stereo3d/injector/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000001"
.end annotation


# instance fields
.field private final this$0:Lcom/stereo3d/injector/MainActivity;


# direct methods
.method constructor <init>(Lcom/stereo3d/injector/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/stereo3d/injector/MainActivity$100000001;->this$0:Lcom/stereo3d/injector/MainActivity;

    return-void
.end method

.method static access$0(Lcom/stereo3d/injector/MainActivity$100000001;)Lcom/stereo3d/injector/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/stereo3d/injector/MainActivity$100000001;->this$0:Lcom/stereo3d/injector/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onTouch(Landroid/view/View;Landroid/view/MotionEvent;)Z
    .locals 9
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    .line 125
    move-object v0, p0

    move-object v1, p1

    move-object v2, p2

    move-object v6, v1

    invoke-virtual {v6}, Landroid/view/View;->requestFocus()Z

    move-result v6

    .line 126
    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity$100000001;->this$0:Lcom/stereo3d/injector/MainActivity;

    const-string v7, "input_method"

    invoke-virtual {v6, v7}, Lcom/stereo3d/injector/MainActivity;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v6

    check-cast v6, Landroid/view/inputmethod/InputMethodManager;

    move-object v4, v6

    .line 127
    move-object v6, v4

    if-eqz v6, :cond_0

    .line 128
    move-object v6, v4

    move-object v7, v0

    iget-object v7, v7, Lcom/stereo3d/injector/MainActivity$100000001;->this$0:Lcom/stereo3d/injector/MainActivity;

    invoke-static {v7}, Lcom/stereo3d/injector/MainActivity;->access$L1000003(Lcom/stereo3d/injector/MainActivity;)Landroid/webkit/WebView;

    move-result-object v7

    invoke-virtual {v7}, Landroid/webkit/WebView;->getWindowToken()Landroid/os/IBinder;

    move-result-object v7

    const/4 v8, 0x0

    invoke-virtual {v6, v7, v8}, Landroid/view/inputmethod/InputMethodManager;->hideSoftInputFromWindow(Landroid/os/IBinder;I)Z

    move-result v6

    .line 130
    :cond_0
    const/4 v6, 0x0

    move v0, v6

    return v0
.end method
