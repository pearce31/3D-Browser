.class public Lcom/stereo3d/injector/MainActivity;
.super Landroid/app/Activity;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/stereo3d/injector/MainActivity$100000000;,
        Lcom/stereo3d/injector/MainActivity$100000001;,
        Lcom/stereo3d/injector/MainActivity$100000002;
    }
.end annotation


# instance fields
.field private btn:Landroid/widget/Button;

.field private currentMode:I

.field private root:Landroid/widget/FrameLayout;

.field private webView:Landroid/webkit/WebView;

.field t3dPanel:Z

.field cLong:Z

.field ytMode:Z

.field adOff:Z

.field gameMode:Z

.field gfnMode:Z

.field uaMode:I

.field ptX:F

.field ptY:F


# direct methods
.method public constructor <init>()V
    .locals 4

    .prologue
    move-object v0, p0

    move-object v2, v0

    invoke-direct {v2}, Landroid/app/Activity;-><init>()V

    move-object v2, v0

    const/4 v3, 0x0

    iput v3, v2, Lcom/stereo3d/injector/MainActivity;->currentMode:I

    return-void
.end method

.method static synthetic access$1000007(Lcom/stereo3d/injector/MainActivity;)V
    .locals 4

    move-object v0, p0

    move-object v3, v0

    invoke-direct {v3}, Lcom/stereo3d/injector/MainActivity;->inject3D()V

    return-void
.end method

.method static synthetic access$L1000000(Lcom/stereo3d/injector/MainActivity;)I
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget v3, v3, Lcom/stereo3d/injector/MainActivity;->currentMode:I

    move v0, v3

    return v0
.end method

.method static synthetic access$L1000002(Lcom/stereo3d/injector/MainActivity;)Landroid/widget/Button;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    move-object v0, v3

    return-object v0
.end method

.method static synthetic access$L1000003(Lcom/stereo3d/injector/MainActivity;)Landroid/webkit/WebView;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    move-object v0, v3

    return-object v0
.end method

.method static synthetic access$S1000000(Lcom/stereo3d/injector/MainActivity;I)V
    .locals 6

    move-object v0, p0

    move v1, p1

    move-object v4, v0

    move v5, v1

    iput v5, v4, Lcom/stereo3d/injector/MainActivity;->currentMode:I

    return-void
.end method

.method static synthetic access$S1000002(Lcom/stereo3d/injector/MainActivity;Landroid/widget/Button;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    return-void
.end method

.method static synthetic access$S1000003(Lcom/stereo3d/injector/MainActivity;Landroid/webkit/WebView;)V
    .locals 6

    move-object v0, p0

    move-object v1, p1

    move-object v4, v0

    move-object v5, v1

    iput-object v5, v4, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    return-void
.end method

.method private inject3D()V
    .locals 7

    :try_start_0
    invoke-virtual {p0}, Lcom/stereo3d/injector/MainActivity;->getAssets()Landroid/content/res/AssetManager;
    move-result-object v0
    const-string v1, "app.js"
    invoke-virtual {v0, v1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;
    move-result-object v0

    new-instance v1, Ljava/io/ByteArrayOutputStream;
    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/16 v2, 0x1000
    new-array v2, v2, [B

    :goto_0
    invoke-virtual {v0, v2}, Ljava/io/InputStream;->read([B)I
    move-result v3
    const/4 v4, -0x1
    if-eq v3, v4, :cond_0
    const/4 v4, 0x0
    invoke-virtual {v1, v2, v4, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V
    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B
    move-result-object v4
    new-instance v5, Ljava/lang/String;
    const-string v6, "UTF-8"
    invoke-direct {v5, v4, v6}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    iget-object v6, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const/4 v0, 0x0
    invoke-virtual {v6, v5, v0}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :goto_1
    return-void

    :catch_0
    move-exception v0
    goto :goto_1
.end method


# virtual methods
.method public dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .locals 5
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    move-object v0, p0

    move-object v1, p1

    move-object v3, v1

    invoke-virtual {v3}, Landroid/view/MotionEvent;->getSource()I

    move-result v3

    const v4, 0x1000010

    and-int/2addr v3, v4

    const v4, 0x1000010

    if-ne v3, v4, :cond_0

    move-object v3, v0

    iget-object v3, v3, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    move-object v4, v1

    invoke-virtual {v3, v4}, Landroid/webkit/WebView;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v3

    move v0, v3

    :goto_0
    return v0

    :cond_0
    move-object v3, v0

    move-object v4, v1

    invoke-super {v3, v4}, Landroid/app/Activity;->dispatchGenericMotionEvent(Landroid/view/MotionEvent;)Z

    move-result v3

    move v0, v3

    goto :goto_0
.end method

.method private immersive()V
    .locals 2
    invoke-virtual {p0}, Lcom/stereo3d/injector/MainActivity;->getWindow()Landroid/view/Window;
    move-result-object v0
    invoke-virtual {v0}, Landroid/view/Window;->getDecorView()Landroid/view/View;
    move-result-object v0
    const v1, 0x1706
    invoke-virtual {v0, v1}, Landroid/view/View;->setSystemUiVisibility(I)V
    return-void
.end method

.method public onWindowFocusChanged(Z)V
    .locals 0
    invoke-super {p0, p1}, Landroid/app/Activity;->onWindowFocusChanged(Z)V
    if-eqz p1, :imm_done
    invoke-direct {p0}, Lcom/stereo3d/injector/MainActivity;->immersive()V
    :imm_done
    return-void
.end method

.method private tapWeb()V
    .locals 12
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J
    move-result-wide v0
    move-wide v2, v0
    iget-object v8, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v8}, Landroid/view/View;->getWidth()I
    move-result v8
    int-to-float v8, v8
    iget v9, p0, Lcom/stereo3d/injector/MainActivity;->ptX:F
    mul-float v5, v8, v9
    iget-object v8, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v8}, Landroid/view/View;->getHeight()I
    move-result v8
    int-to-float v8, v8
    iget v9, p0, Lcom/stereo3d/injector/MainActivity;->ptY:F
    mul-float v6, v8, v9
    const/4 v7, 0x0
    const/4 v4, 0x0
    invoke-static/range {v0 .. v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;
    move-result-object v10
    iget-object v8, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v8, v10}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    invoke-virtual {v10}, Landroid/view/MotionEvent;->recycle()V
    const/4 v4, 0x1
    invoke-static/range {v0 .. v7}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;
    move-result-object v10
    iget-object v8, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v8, v10}, Landroid/view/View;->dispatchTouchEvent(Landroid/view/MotionEvent;)Z
    invoke-virtual {v10}, Landroid/view/MotionEvent;->recycle()V
    return-void
.end method

.method public dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    .locals 5
    .annotation runtime Ljava/lang/Override;
    .end annotation

    invoke-virtual {p1}, Landroid/view/KeyEvent;->getKeyCode()I
    move-result v0
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getAction()I
    move-result v1

    iget-boolean v2, p0, Lcom/stereo3d/injector/MainActivity;->gameMode:Z
    if-eqz v2, :normalkeys
    iget-boolean v2, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-nez v2, :normalkeys
    const/16 v2, 0x17
    if-eq v0, v2, :center
    const/16 v2, 0x42
    if-eq v0, v2, :center
    iget-object v2, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v2, p1}, Landroid/webkit/WebView;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v2
    if-nez v2, :gm_ret1
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v2
    if-nez v2, :gm_ret1
    const/4 v2, 0x0
    return v2
    :gm_ret1
    const/4 v2, 0x1
    return v2
    :normalkeys
    const/4 v2, 0x4
    if-ne v0, v2, :not_backkey
    if-nez v1, :back_consume
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-eqz v3, :back_nopanel
    const/4 v3, 0x0
    iput-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const-string v4, "window.__t3dPanel&&window.__t3dPanel(false)"
    const/4 v2, 0x0
    invoke-virtual {v3, v4, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :back_nopanel
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->ytMode:Z
    if-eqz v3, :back_browser
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const-string v4, "window.__t3dBack&&window.__t3dBack()"
    const/4 v2, 0x0
    invoke-virtual {v3, v4, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :back_browser
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const-string v4, "window.__t3dBackBrowser&&window.__t3dBackBrowser()"
    const/4 v2, 0x0
    invoke-virtual {v3, v4, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :back_consume
    const/4 v2, 0x1
    return v2

    :not_backkey
    const/16 v2, 0x17
    if-eq v0, v2, :center
    const/16 v2, 0x42
    if-eq v0, v2, :center
    goto :arrow_check

    :center
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->cLong:Z
    if-eqz v3, :center_notlong
    if-nez v1, :center_up_long
    const/4 v2, 0x1
    return v2
    :center_up_long
    const/4 v3, 0x0
    iput-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->cLong:Z
    const/4 v2, 0x1
    return v2
    :center_notlong
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-nez v3, :after_center
    if-nez v1, :center_short
    invoke-virtual {p1}, Landroid/view/KeyEvent;->getRepeatCount()I
    move-result v2
    if-nez v2, :center_begin_long
    const/4 v2, 0x1
    return v2
    :center_begin_long
    const/4 v3, 0x1
    iput-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->cLong:Z
    iput-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const-string v4, "window.__t3dPanel&&window.__t3dPanel(true)"
    const/4 v2, 0x0
    invoke-virtual {v3, v4, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :center_short
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->ytMode:Z
    if-nez v3, :center_do_synth
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->gameMode:Z
    if-eqz v3, :center_click
    :center_do_synth
    new-instance v2, Landroid/view/KeyEvent;
    const/4 v3, 0x0
    invoke-direct {v2, v3, v0}, Landroid/view/KeyEvent;-><init>(II)V
    iget-object v4, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v4, v2}, Landroid/webkit/WebView;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    new-instance v2, Landroid/view/KeyEvent;
    const/4 v3, 0x1
    invoke-direct {v2, v3, v0}, Landroid/view/KeyEvent;-><init>(II)V
    iget-object v4, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v4, v2}, Landroid/webkit/WebView;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    iget-object v4, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const-string v3, "window.__t3dPoke&&window.__t3dPoke()"
    const/4 v2, 0x0
    invoke-virtual {v4, v3, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :center_click
    invoke-direct {p0}, Lcom/stereo3d/injector/MainActivity;->tapWeb()V
    const/4 v2, 0x1
    return v2

    :arrow_check
    const/16 v2, 0x13
    if-lt v0, v2, :after_center
    const/16 v2, 0x16
    if-gt v0, v2, :after_center
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-nez v3, :after_center
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->ytMode:Z
    if-nez v3, :after_center
    if-nez v1, :arrow_up
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "window.__t3dCursor&&window.__t3dCursor("
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, ")"
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const/4 v4, 0x0
    invoke-virtual {v3, v2, v4}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :arrow_up
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "window.__t3dCursorUp&&window.__t3dCursorUp("
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, ")"
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const/4 v4, 0x0
    invoke-virtual {v3, v2, v4}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2
    :after_center
    if-nez v1, :forward
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-nez v3, :mchk
    const/16 v2, 0x13
    if-lt v0, v2, :mchk
    const/16 v2, 0x16
    if-gt v0, v2, :mchk
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->ytMode:Z
    if-eqz v3, :arrow_cursor
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const-string v4, "window.__t3dPoke&&window.__t3dPoke()"
    const/4 v2, 0x0
    invoke-virtual {v3, v4, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    goto :forward
    :arrow_cursor
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "window.__t3dCursor&&window.__t3dCursor("
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, ")"
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const/4 v4, 0x0
    invoke-virtual {v3, v2, v4}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2

    :mchk
    const/16 v2, 0x52
    if-eq v0, v2, :do_menu
    const/16 v2, 0xa5
    if-eq v0, v2, :do_menu
    const/16 v2, 0xac
    if-eq v0, v2, :do_menu
    const/16 v2, 0xb0
    if-eq v0, v2, :do_menu

    :check_panel
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-eqz v3, :forward
    const/16 v2, 0x13
    if-lt v0, v2, :maybe_enter
    const/16 v2, 0x17
    if-gt v0, v2, :maybe_enter
    goto :send_key
    :maybe_enter
    const/16 v2, 0x42
    if-eq v0, v2, :send_key
    const/4 v2, 0x1
    return v2

    :do_menu
    iget-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-nez v3, :menu_off
    const/4 v3, 0x1
    iput-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    const-string v4, "window.__t3dPanel&&window.__t3dPanel(true)"
    goto :menu_eval
    :menu_off
    const/4 v3, 0x0
    iput-boolean v3, p0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    const-string v4, "window.__t3dPanel&&window.__t3dPanel(false)"
    :menu_eval
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const/4 v2, 0x0
    invoke-virtual {v3, v4, v2}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2

    :send_key
    new-instance v2, Ljava/lang/StringBuilder;
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V
    const-string v3, "window.__t3dKey&&window.__t3dKey("
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;
    move-result-object v2
    const-string v3, ")"
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;
    move-result-object v2
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;
    move-result-object v2
    iget-object v3, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    const/4 v4, 0x0
    invoke-virtual {v3, v2, v4}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    const/4 v2, 0x1
    return v2

    :forward
    iget-object v2, p0, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    invoke-virtual {v2, p1}, Landroid/webkit/WebView;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v2
    if-nez v2, :fdone
    invoke-super {p0, p1}, Landroid/app/Activity;->dispatchKeyEvent(Landroid/view/KeyEvent;)Z
    move-result v2
    :fdone
    return v2
.end method

.method public onBackPressed()V
    .locals 3
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    move-object v0, p0

    move-object v2, v0

    iget-object v2, v2, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    invoke-virtual {v2}, Landroid/webkit/WebView;->canGoBack()Z

    move-result v2

    if-eqz v2, :cond_0

    move-object v2, v0

    iget-object v2, v2, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    invoke-virtual {v2}, Landroid/webkit/WebView;->goBack()V

    :goto_0
    return-void

    :cond_0
    move-object v2, v0

    invoke-super {v2}, Landroid/app/Activity;->onBackPressed()V

    goto :goto_0
.end method

.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 5
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    move-object v4, v1

    invoke-super {v3, v4}, Landroid/app/Activity;->onConfigurationChanged(Landroid/content/res/Configuration;)V

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 12
    .annotation runtime Ljava/lang/Override;
    .end annotation

    .prologue
    move-object v0, p0

    move-object v1, p1

    move-object v6, v0

    const-string v7, "com.aide.ui"

    invoke-static {v6, v7}, Ladrt/ADRTLogCatReader;->onContext(Landroid/content/Context;Ljava/lang/String;)V

    move-object v6, v0

    move-object v7, v1

    invoke-super {v6, v7}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    move-object v6, v0

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Lcom/stereo3d/injector/MainActivity;->requestWindowFeature(I)Z

    move-result v6

    move-object v6, v0

    invoke-virtual {v6}, Lcom/stereo3d/injector/MainActivity;->getWindow()Landroid/view/Window;

    move-result-object v6

    const/16 v7, 0x400

    const/16 v8, 0x400

    invoke-virtual {v6, v7, v8}, Landroid/view/Window;->setFlags(II)V

    move-object v6, v0

    new-instance v7, Landroid/widget/FrameLayout;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/FrameLayout;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    const/high16 v7, -0x1000000

    invoke-virtual {v6, v7}, Landroid/widget/FrameLayout;->setBackgroundColor(I)V

    move-object v6, v0

    new-instance v7, Landroid/webkit/WebView;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/webkit/WebView;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v7, Landroid/widget/FrameLayout$LayoutParams;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    const/4 v9, -0x1

    const/4 v10, -0x1

    invoke-direct {v8, v9, v10}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    const/high16 v7, -0x1000000

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setBackgroundColor(I)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    const/4 v7, 0x0

    const/4 v8, 0x0

    check-cast v8, Landroid/graphics/Paint;

    invoke-virtual {v6, v7, v8}, Landroid/webkit/WebView;->setLayerType(ILandroid/graphics/Paint;)V

    move-object v6, v0

    new-instance v7, Landroid/widget/Button;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    iput-object v7, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    const-string v7, "3D"

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setText(Ljava/lang/CharSequence;)V

    const/16 v7, 0x8

    invoke-virtual {v6, v7}, Landroid/view/View;->setVisibility(I)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    const v7, 0x3ecccccd    # 0.4f

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setAlpha(F)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    const-string v7, "#333333"

    invoke-static {v7}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v7

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setBackgroundColor(I)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    const/4 v7, -0x1

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setTextColor(I)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    const/high16 v7, 0x41300000    # 11.0f

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setTextSize(F)V

    new-instance v6, Landroid/widget/FrameLayout$LayoutParams;

    move-object v11, v6

    move-object v6, v11

    move-object v7, v11

    const/16 v8, 0xaa

    const/16 v9, 0x46

    invoke-direct {v7, v8, v9}, Landroid/widget/FrameLayout$LayoutParams;-><init>(II)V

    move-object v3, v6

    move-object v6, v3

    const/16 v7, 0x33

    iput v7, v6, Landroid/widget/FrameLayout$LayoutParams;->gravity:I

    move-object v6, v3

    const/16 v7, 0x1e

    const/16 v8, 0x1e

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v6, v7, v8, v9, v10}, Landroid/widget/FrameLayout$LayoutParams;->setMargins(IIII)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    invoke-virtual {v6}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;

    move-result-object v6

    move-object v4, v6

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setJavaScriptEnabled(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setDomStorageEnabled(Z)V

    move-object v6, v4

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setMediaPlaybackRequiresUserGesture(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setAllowUniversalAccessFromFileURLs(Z)V

    move-object v6, v4

    const-string v7, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setUseWideViewPort(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setLoadWithOverviewMode(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setBuiltInZoomControls(Z)V

    move-object v6, v4

    const/4 v7, 0x0

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setDisplayZoomControls(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setDatabaseEnabled(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setAllowFileAccess(Z)V

    move-object v6, v4

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebSettings;->setAllowContentAccess(Z)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setFocusable(Z)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setFocusableInTouchMode(Z)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v7, Landroid/webkit/WebChromeClient;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    invoke-direct {v8}, Landroid/webkit/WebChromeClient;-><init>()V

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setWebChromeClient(Landroid/webkit/WebChromeClient;)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v7, Lcom/stereo3d/injector/MainActivity$100000000;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lcom/stereo3d/injector/MainActivity$100000000;-><init>(Lcom/stereo3d/injector/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setWebViewClient(Landroid/webkit/WebViewClient;)V

    move-object v6, v0
    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;
    new-instance v7, Lcom/stereo3d/injector/Bridge;
    move-object v8, v0
    invoke-direct {v7, v8}, Lcom/stereo3d/injector/Bridge;-><init>(Landroid/content/Context;)V
    const-string v8, "NativeBridge"
    invoke-virtual {v6, v7, v8}, Landroid/webkit/WebView;->addJavascriptInterface(Ljava/lang/Object;Ljava/lang/String;)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    new-instance v7, Lcom/stereo3d/injector/MainActivity$100000001;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lcom/stereo3d/injector/MainActivity$100000001;-><init>(Lcom/stereo3d/injector/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->setOnTouchListener(Landroid/view/View$OnTouchListener;)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    new-instance v7, Lcom/stereo3d/injector/MainActivity$100000002;

    move-object v11, v7

    move-object v7, v11

    move-object v8, v11

    move-object v9, v0

    invoke-direct {v8, v9}, Lcom/stereo3d/injector/MainActivity$100000002;-><init>(Lcom/stereo3d/injector/MainActivity;)V

    invoke-virtual {v6, v7}, Landroid/widget/Button;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    move-object v7, v0

    iget-object v7, v7, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    invoke-virtual {v6, v7}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    move-object v7, v0

    iget-object v7, v7, Lcom/stereo3d/injector/MainActivity;->btn:Landroid/widget/Button;

    move-object v8, v3

    invoke-virtual {v6, v7, v8}, Landroid/widget/FrameLayout;->addView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    move-object v6, v0

    move-object v7, v0

    iget-object v7, v7, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    invoke-virtual {v6, v7}, Lcom/stereo3d/injector/MainActivity;->setContentView(Landroid/view/View;)V

    invoke-direct {p0}, Lcom/stereo3d/injector/MainActivity;->immersive()V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/FrameLayout;->setFocusable(Z)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    const/4 v7, 0x1

    invoke-virtual {v6, v7}, Landroid/widget/FrameLayout;->setFocusableInTouchMode(Z)V

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->root:Landroid/widget/FrameLayout;

    invoke-virtual {v6}, Landroid/widget/FrameLayout;->requestFocus()Z

    move-result v6

    move-object v6, v0

    iget-object v6, v6, Lcom/stereo3d/injector/MainActivity;->webView:Landroid/webkit/WebView;

    const-string v7, "file:///android_asset/home.html"

    invoke-virtual {v6, v7}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V

    return-void
.end method
