.class Lcom/stereo3d/injector/MainActivity$100000000;
.super Landroid/webkit/WebViewClient;
.source "MainActivity.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/stereo3d/injector/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000000"
.end annotation


# instance fields
.field private final this$0:Lcom/stereo3d/injector/MainActivity;


# direct methods
.method constructor <init>(Lcom/stereo3d/injector/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Landroid/webkit/WebViewClient;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/stereo3d/injector/MainActivity$100000000;->this$0:Lcom/stereo3d/injector/MainActivity;

    return-void
.end method

.method static access$0(Lcom/stereo3d/injector/MainActivity$100000000;)Lcom/stereo3d/injector/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/stereo3d/injector/MainActivity$100000000;->this$0:Lcom/stereo3d/injector/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onPageFinished(Landroid/webkit/WebView;Ljava/lang/String;)V
    .locals 4
    .annotation runtime Ljava/lang/Override;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/MainActivity$100000000;->this$0:Lcom/stereo3d/injector/MainActivity;
    const/4 v1, 0x0
    iput-boolean v1, v0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-eqz p2, :skip
    const-string v1, "youtube"
    invoke-virtual {p2, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-eqz v1, :setyt
    const-string v2, "uimode"
    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Landroid/app/UiModeManager;
    invoke-virtual {v2}, Landroid/app/UiModeManager;->getCurrentModeType()I
    move-result v2
    const/4 v3, 0x4
    if-eq v2, v3, :setyt
    const/4 v1, 0x0
    :setyt
    iput-boolean v1, v0, Lcom/stereo3d/injector/MainActivity;->ytMode:Z
    :skip
    invoke-static {v0}, Lcom/stereo3d/injector/MainActivity;->access$1000007(Lcom/stereo3d/injector/MainActivity;)V
    return-void
.end method

.method public shouldOverrideUrlLoading(Landroid/webkit/WebView;Ljava/lang/String;)Z
    .locals 7
    .annotation runtime Ljava/lang/Override;
    .end annotation
    if-eqz p2, :notHome
    const-string v2, "t3d.home"
    invoke-virtual {p2, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v2
    if-eqz v2, :notHome
    const-string v2, "file:///android_asset/home.html"
    invoke-virtual {p1, v2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    const/4 v0, 0x1
    return v0
    :notHome
    iget-object v0, p0, Lcom/stereo3d/injector/MainActivity$100000000;->this$0:Lcom/stereo3d/injector/MainActivity;
    const/4 v1, 0x0
    if-eqz p2, :w
    const-string v2, "youtube"
    invoke-virtual {p2, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    :w
    const-string v2, "uimode"
    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Landroid/app/UiModeManager;
    invoke-virtual {v2}, Landroid/app/UiModeManager;->getCurrentModeType()I
    move-result v2
    const/4 v3, 0x4
    if-ne v2, v3, :noytr
    if-eqz v1, :noytr
    const-string v3, "/tv"
    invoke-virtual {p2, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v3
    if-nez v3, :noytr
    const/4 v3, 0x1
    iput v3, v0, Lcom/stereo3d/injector/MainActivity;->uaMode:I
    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v3
    const-string v4, "Mozilla/5.0 (SMART-TV; LINUX; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) 76.0.3809.146/6.0 TV Safari/537.36"
    invoke-virtual {v3, v4}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V
    const-string v3, "https://www.youtube.com/tv"
    invoke-virtual {p1, v3}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    const/4 v0, 0x1
    return v0
    :noytr
    const/4 v3, 0x4
    if-eq v2, v3, :istv
    const/4 v4, 0x2
    goto :havedesired
    :istv
    if-eqz v1, :deskmode
    const/4 v4, 0x1
    goto :havedesired
    :deskmode
    const/4 v4, 0x0
    :havedesired
    iget v5, v0, Lcom/stereo3d/injector/MainActivity;->uaMode:I
    if-eq v5, v4, :normal
    iput v4, v0, Lcom/stereo3d/injector/MainActivity;->uaMode:I
    invoke-virtual {p1}, Landroid/webkit/WebView;->getSettings()Landroid/webkit/WebSettings;
    move-result-object v5
    const/4 v6, 0x1
    if-ne v4, v6, :notTvUa
    const-string v6, "Mozilla/5.0 (SMART-TV; LINUX; Tizen 6.0) AppleWebKit/537.36 (KHTML, like Gecko) 76.0.3809.146/6.0 TV Safari/537.36"
    goto :setua
    :notTvUa
    const/4 v6, 0x2
    if-ne v4, v6, :deskUa
    const-string v6, "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36"
    goto :setua
    :deskUa
    const-string v6, "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36"
    :setua
    invoke-virtual {v5, v6}, Landroid/webkit/WebSettings;->setUserAgentString(Ljava/lang/String;)V
    invoke-virtual {p1, p2}, Landroid/webkit/WebView;->loadUrl(Ljava/lang/String;)V
    const/4 v0, 0x1
    return v0
    :normal
    const/4 v0, 0x0
    return v0
.end method

.method public shouldInterceptRequest(Landroid/webkit/WebView;Ljava/lang/String;)Landroid/webkit/WebResourceResponse;
    .locals 6
    .annotation runtime Ljava/lang/Override;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/MainActivity$100000000;->this$0:Lcom/stereo3d/injector/MainActivity;
    iget-boolean v0, v0, Lcom/stereo3d/injector/MainActivity;->adOff:Z
    if-nez v0, :pass
    if-eqz p2, :pass
    const-string v0, "doubleclick.net"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "googlesyndication.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "googleadservices.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "google-analytics.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "adservice.google"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "adnxs.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "amazon-adsystem.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "adsafeprotected.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "scorecardresearch.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "moatads.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "taboola.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "outbrain.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "criteo"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "pubmatic.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "rubiconproject.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "casalemedia.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "openx.net"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "2mdn.net"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "zedo.com"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    const-string v0, "adform.net"
    invoke-virtual {p2, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z
    move-result v1
    if-nez v1, :block
    :pass
    const/4 v0, 0x0
    return-object v0
    :block
    new-instance v2, Landroid/webkit/WebResourceResponse;
    const-string v3, "text/plain"
    const-string v4, "utf-8"
    new-instance v5, Ljava/io/ByteArrayInputStream;
    const/4 v0, 0x0
    new-array v0, v0, [B
    invoke-direct {v5, v0}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    invoke-direct {v2, v3, v4, v5}, Landroid/webkit/WebResourceResponse;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/io/InputStream;)V
    return-object v2
.end method
