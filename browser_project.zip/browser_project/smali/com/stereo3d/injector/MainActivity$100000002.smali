.class Lcom/stereo3d/injector/MainActivity$100000002;
.super Ljava/lang/Object;
.source "MainActivity.java"

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/stereo3d/injector/MainActivity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x20
    name = "100000002"
.end annotation


# instance fields
.field private final this$0:Lcom/stereo3d/injector/MainActivity;


# direct methods
.method constructor <init>(Lcom/stereo3d/injector/MainActivity;)V
    .locals 5

    move-object v0, p0

    move-object v1, p1

    move-object v3, v0

    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    move-object v3, v0

    move-object v4, v1

    iput-object v4, v3, Lcom/stereo3d/injector/MainActivity$100000002;->this$0:Lcom/stereo3d/injector/MainActivity;

    return-void
.end method

.method static access$0(Lcom/stereo3d/injector/MainActivity$100000002;)Lcom/stereo3d/injector/MainActivity;
    .locals 4

    move-object v0, p0

    move-object v3, v0

    iget-object v3, v3, Lcom/stereo3d/injector/MainActivity$100000002;->this$0:Lcom/stereo3d/injector/MainActivity;

    move-object v0, v3

    return-object v0
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4
    .annotation runtime Ljava/lang/Override;
    .end annotation

    iget-object v0, p0, Lcom/stereo3d/injector/MainActivity$100000002;->this$0:Lcom/stereo3d/injector/MainActivity;
    iget-boolean v1, v0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    if-nez v1, :off
    const/4 v1, 0x1
    iput-boolean v1, v0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    const-string v2, "window.__t3dPanel&&window.__t3dPanel(true)"
    goto :ev
    :off
    const/4 v1, 0x0
    iput-boolean v1, v0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    const-string v2, "window.__t3dPanel&&window.__t3dPanel(false)"
    :ev
    invoke-static {v0}, Lcom/stereo3d/injector/MainActivity;->access$L1000003(Lcom/stereo3d/injector/MainActivity;)Landroid/webkit/WebView;
    move-result-object v3
    const/4 v1, 0x0
    invoke-virtual {v3, v2, v1}, Landroid/webkit/WebView;->evaluateJavascript(Ljava/lang/String;Landroid/webkit/ValueCallback;)V
    return-void
.end method
