.class public Lcom/stereo3d/injector/Bridge;
.super Ljava/lang/Object;
.source "Bridge.java"

.implements Ljava/lang/Runnable;

.field private c:Landroid/content/Context;

.method constructor <init>(Landroid/content/Context;)V
    .locals 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V
    iput-object p1, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    return-void
.end method

.method public load(Ljava/lang/String;)Ljava/lang/String;
    .locals 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    const-string v1, "t3d"
    const/4 v2, 0x0
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    const-string v1, ""
    invoke-interface {v0, p1, v1}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    move-result-object v0
    return-object v0
.end method

.method public save(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    const-string v1, "t3d"
    const/4 v2, 0x0
    invoke-virtual {v0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    invoke-interface {v0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;
    move-result-object v0
    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    return-void
.end method

.method public isTv()Z
    .locals 3
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    const-string v1, "uimode"
    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v0
    check-cast v0, Landroid/app/UiModeManager;
    invoke-virtual {v0}, Landroid/app/UiModeManager;->getCurrentModeType()I
    move-result v0
    const/4 v1, 0x4
    if-ne v0, v1, :no
    const/4 v0, 0x1
    return v0
    :no
    const/4 v0, 0x0
    return v0
.end method

.method public setPanel(Z)V
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    check-cast v0, Lcom/stereo3d/injector/MainActivity;
    iput-boolean p1, v0, Lcom/stereo3d/injector/MainActivity;->t3dPanel:Z
    return-void
.end method

.method public showKeyboard()V
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    check-cast v0, Landroid/app/Activity;
    invoke-virtual {v0, p0}, Landroid/app/Activity;->runOnUiThread(Ljava/lang/Runnable;)V
    return-void
.end method

.method public run()V
    .locals 3
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    check-cast v0, Lcom/stereo3d/injector/MainActivity;
    invoke-static {v0}, Lcom/stereo3d/injector/MainActivity;->access$L1000003(Lcom/stereo3d/injector/MainActivity;)Landroid/webkit/WebView;
    move-result-object v1
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    const-string v2, "input_method"
    invoke-virtual {v0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;
    move-result-object v2
    check-cast v2, Landroid/view/inputmethod/InputMethodManager;
    invoke-virtual {v1}, Landroid/webkit/WebView;->requestFocus()Z
    const/4 v0, 0x0
    invoke-virtual {v2, v1, v0}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z
    return-void
.end method

.method public setAdOff(Z)V
    .locals 1
    .annotation runtime Landroid/webkit/JavascriptInterface;
    .end annotation
    iget-object v0, p0, Lcom/stereo3d/injector/Bridge;->c:Landroid/content/Context;
    check-cast v0, Lcom/stereo3d/injector/MainActivity;
    iput-boolean p1, v0, Lcom/stereo3d/injector/MainActivity;->adOff:Z
    return-void
.end method
