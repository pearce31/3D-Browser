/* 3D Tube injector — runs on YouTube pages (incl. the TV / leanback UI).
   - green/magenta anaglyph overlay (crosstalk-corrected shader)
   - ad auto-skip / mute + black cover over the ad frame
   - 3D settings panel, opened by the native shell (Menu button or the on-screen
     "3D" button) which also routes the D-pad into the panel so you can adjust with the remote.
   The panel self-heals: if the YouTube TV app wipes the DOM, it is rebuilt. */
(function(){
  if (window.__TUBE3D__) return;
  window.__TUBE3D__ = true;

  function num(k,d){ var v=parseFloat(localStorage.getItem(k)); return isNaN(v)?d:v; }
  var CFG = {
    on:      (function(){ var v=localStorage.getItem('t3d_on'); return v===null?true:v==='1'; })(),
    depth:   num('t3d_depth',30),
    green:   num('t3d_green',0.80),
    ghost:   num('t3d_ghost',0.22),
    desat:   num('t3d_desat',0.35),
    converge:num('t3d_converge',0.002),
    coverControls:(localStorage.getItem('t3d_cover')==='1'),
    mode:(localStorage.getItem('t3d_mode')==='1')?1:0,   // 0=green/magenta, 1=red/cyan
    source:(function(){ var v=parseInt(localStorage.getItem('t3d_source'),10); return isNaN(v)?0:v; }()), // 0=2D,1=SBS,2=TAB,3=Auto
    swap:(localStorage.getItem('t3d_swap')==='1'),
    ads: true
  };
  function save(k,v){ localStorage.setItem(k,String(v)); }

  /* ---------------- WebGL overlay ---------------- */
  var VS="attribute vec2 p;varying vec2 uv;void main(){uv=p*0.5+0.5;gl_Position=vec4(p,0.,1.);}";
  var FS=[
  "precision highp float;","varying vec2 uv;","uniform sampler2D uTex;",
  "uniform vec2 uTexSize,uCanvasSize;","uniform vec4 uCrop;",
  "uniform float uStrength,uGreenGain,uDesat,uGhost,uConverge,uMode,uSource,uSwap;",
  "const vec3 LUMA=vec3(0.299,0.587,0.114);",
  "vec3 toLin(vec3 c){return pow(c,vec3(2.2));}",
  "vec3 toSrgb(vec3 c){return pow(max(c,0.0),vec3(1.0/2.2));}",
  "void main(){",
  " float ca=uCanvasSize.x/max(uCanvasSize.y,1.0);",
  " float va; float asp=uTexSize.x/max(uTexSize.y,1.0);",
  " if(uSource<0.5) va=asp;",                                               // 2D full frame
  " else if(uSource<1.5) va=(asp>2.2)?(uTexSize.x*0.5)/max(uTexSize.y,1.0):asp;", // SBS: half-width only if double-wide, else unsqueeze
  " else va=(asp<1.3)?uTexSize.x/max(uTexSize.y*0.5,1.0):asp;",            // TAB: half-height only if double-tall, else unsqueeze
  " vec2 s=ca>va?vec2(va/ca,1.0):vec2(1.0,ca/va);",
  " vec2 u=(uv-0.5)/s+0.5;",
  " float inB=step(0.0,u.x)*step(u.x,1.0)*step(0.0,u.y)*step(u.y,1.0);",
  " float conv=(uSource<0.5)?uConverge:uConverge*4.0;",
  " vec3 cL,cR;",
  " if(uSource<0.5){",   // 2D -> fake luminance depth (unchanged)
  "   float l=dot(texture2D(uTex,u).rgb,LUMA);",
  "   float lL=dot(texture2D(uTex,u-vec2(4.0/uTexSize.x,0.0)).rgb,LUMA);",
  "   float lR=dot(texture2D(uTex,u+vec2(4.0/uTexSize.x,0.0)).rgb,LUMA);",
  "   float smL=(l+lR+lL)/3.0; float dist=distance(u,vec2(0.5));",
  "   float z=((0.35-dist)*0.8+(smL-0.5)*0.25)*uStrength;",
  "   vec2 uL=vec2(clamp(u.x-z+conv,0.001,0.999),u.y);",
  "   vec2 uR=vec2(clamp(u.x+z-conv,0.001,0.999),u.y);",
  "   cL=toLin(texture2D(uTex,uL).rgb); cR=toLin(texture2D(uTex,uR).rgb);",
  " } else if(uSource<1.5){",  // SBS real stereo: left half / right half
  "   vec2 lv=vec2(clamp(u.x*0.5+conv,0.0,0.5),u.y);",
  "   vec2 rv=vec2(clamp(u.x*0.5+0.5-conv,0.5,1.0),u.y);",
  "   if(uSwap>0.5){ vec2 t=lv; lv=rv; rv=t; }",
  "   cL=toLin(texture2D(uTex,lv).rgb); cR=toLin(texture2D(uTex,rv).rgb);",
  " } else {",  // TAB real stereo: top half / bottom half
  "   vec2 lv=vec2(clamp(u.x+conv,0.0,1.0),clamp(u.y*0.5+0.5,0.5,1.0));",
  "   vec2 rv=vec2(clamp(u.x-conv,0.0,1.0),clamp(u.y*0.5,0.0,0.5));",
  "   if(uSwap>0.5){ vec2 t=lv; lv=rv; rv=t; }",
  "   cL=toLin(texture2D(uTex,lv).rgb); cR=toLin(texture2D(uTex,rv).rgb);",
  " }",
  " float yL=dot(cL,LUMA),yR=dot(cR,LUMA);",
  " cL=mix(cL,vec3(yL),uDesat); cR=mix(cR,vec3(yR),uDesat);",
  " vec3 outLin;",
  " if(uSource<0.5){",          // 2D fake depth: additive ghost-fill (tiny disparity)
  "   if(uMode<0.5){ float g=cR.g*uGreenGain; float magR=0.7*cL.r+0.3*cL.b+uGhost*g; float magB=0.3*cL.r+0.7*cL.b+uGhost*g; outLin=vec3(magR,g,magB); }",
  "   else { float cg=cR.g*uGreenGain, cb=cR.b*uGreenGain; float yc=(cg+cb)*0.5; float r=cL.r+uGhost*yc; cg=cg+uGhost*r; cb=cb+uGhost*r; outLin=vec3(r,cg,cb); }",
  " } else {",                  // real stereo (SBS/TAB): subtractive crosstalk cancel
  "   vec3 lC=max(cL-cR*uGhost,0.0); vec3 rC=max(cR-cL*uGhost,0.0);",
  "   if(uMode<0.5) outLin=vec3(lC.r, rC.g*uGreenGain, lC.b);",
  "   else outLin=vec3(lC.r, rC.g*uGreenGain, rC.b*uGreenGain);",
  " }",
  " gl_FragColor=mix(vec4(0.0,0.0,0.0,1.0),vec4(toSrgb(outLin),1.0),inB);","}"].join("\n");

  var cv,gl,prog,tex,loc={},glReady=false;
  function compile(t,src){ var s=gl.createShader(t); gl.shaderSource(s,src); gl.compileShader(s);
    if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) console.warn('3DTube shader',gl.getShaderInfoLog(s)); return s; }
  function initGL(){
    cv=document.createElement('canvas'); cv.id='t3d_canvas';
    cv.style.cssText='position:fixed;left:0;top:0;pointer-events:none;z-index:2147482000;display:none;';
    // while 3D covers the screen, the canvas eats the first tap (dismiss only, no pass-through)
    cv.addEventListener('touchstart',function(e){ controlsUntil=Date.now()+4000; e.preventDefault(); e.stopPropagation(); },{passive:false});
    cv.addEventListener('click',function(e){ controlsUntil=Date.now()+4000; e.preventDefault(); e.stopPropagation(); });
    document.documentElement.appendChild(cv);
    gl=cv.getContext('webgl',{alpha:false})||cv.getContext('experimental-webgl'); if(!gl) return;
    prog=gl.createProgram();
    gl.attachShader(prog,compile(gl.VERTEX_SHADER,VS));
    gl.attachShader(prog,compile(gl.FRAGMENT_SHADER,FS));
    gl.linkProgram(prog); gl.useProgram(prog);
    var b=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,b);
    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,1,1]),gl.STATIC_DRAW);
    var la=gl.getAttribLocation(prog,'p'); gl.enableVertexAttribArray(la);
    gl.vertexAttribPointer(la,2,gl.FLOAT,false,0,0);
    ['uTex','uTexSize','uCanvasSize','uCrop','uStrength','uGreenGain','uDesat','uGhost','uConverge','uMode','uSource','uSwap']
      .forEach(function(n){ loc[n]=gl.getUniformLocation(prog,n); });
    tex=gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D,tex);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL,true);
    glReady=true;
  }
  function mainVideo(){ var vs=document.querySelectorAll('video'),best=null,ba=0;
    for(var i=0;i<vs.length;i++){ var v=vs[i],r=v.getBoundingClientRect(),a=r.width*r.height;
      if(v.readyState>=2&&a>ba){ba=a;best=v;} } return best; }

  var uiTick=0;
  function render(){
    requestAnimationFrame(render);
    if((uiTick++%20)===0){ try{ ensureUI(); }catch(e){} }
    if(cv && !cv.isConnected){ try{document.documentElement.appendChild(cv);}catch(e){} }
    if(!glReady||!CFG.on){ if(cv) cv.style.display='none'; return; }
    if(Date.now()<controlsUntil){ cv.style.display='none'; return; }   // showing controls -> raw video
    // On YouTube only 3D the actual watch page, not autoplay previews in the feed
    if(/youtube\.com|youtu\.be/.test(location.hostname) && !/\/watch|watch\?v=|youtu\.be\//.test(location.href)){ cv.style.display='none'; return; }
    var v=mainVideo(); if(!v||v.videoWidth===0){ cv.style.display='none'; return; }
    var r=v.getBoundingClientRect();
    if(r.width*r.height < innerWidth*innerHeight*0.12){ cv.style.display='none'; return; } // ignore tiny preview players
    // 3D fills the screen while it's on (letterboxed by the shader's aspect fit)
    cv.style.display='block'; cv.style.left='0'; cv.style.top='0'; cv.style.width='100%'; cv.style.height='100%';
    cv.style.zIndex=2147483000; cv.style.pointerEvents='auto';
    var dpr=Math.min(window.devicePixelRatio||1,2);
    var W=Math.min(Math.round(innerWidth*dpr),1920),H=Math.min(Math.round(innerHeight*dpr),1080);
    if(cv.width!==W||cv.height!==H){ cv.width=W; cv.height=H; }
    try{
      gl.viewport(0,0,W,H); gl.bindTexture(gl.TEXTURE_2D,tex);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGB,gl.RGB,gl.UNSIGNED_BYTE,v);
      gl.uniform1i(loc.uTex,0); gl.uniform2f(loc.uTexSize,v.videoWidth,v.videoHeight);
      gl.uniform2f(loc.uCanvasSize,W,H); gl.uniform4f(loc.uCrop,0,0,1,1);
      gl.uniform1f(loc.uStrength,(CFG.depth/100)*0.08*(CFG.mode?1.4:1.0));  // g/m original, r/c 1.4x
      gl.uniform1f(loc.uGreenGain,CFG.green); gl.uniform1f(loc.uDesat,CFG.desat);
      gl.uniform1f(loc.uGhost,CFG.ghost); gl.uniform1f(loc.uConverge,CFG.converge);
      gl.uniform1f(loc.uMode,CFG.mode);
      // resolve Auto (3) from the frame shape: double-wide=SBS, double-tall=TAB, else 2D
      var src=CFG.source;
      if(src===3){ var ar=v.videoWidth/Math.max(v.videoHeight,1); src = ar>2.6?1 : (ar<1.2?2:0); }
      gl.uniform1f(loc.uSource,src);
      gl.uniform1f(loc.uSwap,CFG.swap?1:0);
      gl.drawArrays(gl.TRIANGLE_STRIP,0,4);
    }catch(e){}
  }

  /* ---------------- ad auto-skip ---------------- */
  var adCover=null,adCoverStart=0;
  function cover(){ if(!adCover||!adCover.isConnected){ adCover=document.createElement('div'); adCover.id='t3d_adcover';
      adCover.style.cssText='position:fixed;inset:0;background:#000;z-index:2147482500;display:none;pointer-events:none';
      document.documentElement.appendChild(adCover);} return adCover; }
  function adtick(){
    var c=cover(); if(!CFG.ads){ c.style.display='none'; return; }
    try{
      // hide videoless ad units — YouTube only (skip the sweep on other sites to keep them snappy)
      if(/youtube/.test(location.hostname))
      ['ytm-companion-ad-renderer','ytm-promoted-video-renderer','ytm-promoted-sparkles-web-renderer',
       'ytm-promoted-sparkles-text-search-renderer','ytm-ad-slot-renderer','ad-slot-renderer',
       'ytd-ad-slot-renderer','ytd-promoted-video-renderer','ytd-display-ad-renderer','ytd-in-feed-ad-layout-renderer',
       'ytd-banner-promo-renderer','ytd-promoted-sparkles-web-renderer','#masthead-ad','.ytp-ad-overlay-slot',
       '.companion-ad','#player-ads'].forEach(function(s){
        try{ var n=document.querySelectorAll(s); for(var i=0;i<n.length;i++) n[i].style.display='none'; }catch(_){} });
    }catch(e){}
    try{
      var p=document.querySelector('.html5-video-player');
      var sk=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button,'+
        '.ytlr-skip-ad-button,.ytlr-skip-ad-button-renderer,button[aria-label*="Skip"],button[aria-label*="skip"]');
      if(sk) sk.click();
      var ov=document.querySelector('.ytp-ad-overlay-close-button,.ytp-ad-overlay-close-container,.ytlr-ad-action-interstitial-skip-button');
      if(ov) ov.click();
      var ad=(p&&p.classList.contains('ad-showing'))||!!sk||
        !!document.querySelector('.ytp-ad-player-overlay,.ytp-ad-player-overlay-instream-info,.ytlr-ad-interstitial');
      if(ad){ var v=document.querySelector('video');
        if(v){ v.muted=true; if(isFinite(v.duration)&&v.duration>0){ try{v.currentTime=v.duration;}catch(e){} v.playbackRate=16; } }
        if(!adCoverStart) adCoverStart=Date.now();
        c.style.display=(Date.now()-adCoverStart<1500)?'block':'none';  // never black out a whole un-skippable ad
      } else { c.style.display='none'; adCoverStart=0; }
    }catch(e){ c.style.display='none'; }
  }

  /* ---------------- settings panel (self-healing) ---------------- */
  var panel=null,panelOpen=false,rowInputs=[];
  var DEF={depth:30,green:0.80,ghost:0.22,desat:0.35,converge:0.002};
  function selectEl(el){
    if(!panel) return;
    var all=panel.querySelectorAll('.t3d-focusable');
    for(var i=0;i<all.length;i++){ all[i].classList.remove('t3d-sel');
      var pr=all[i].closest?all[i].closest('.t3d-row'):null; if(pr) pr.classList.remove('t3d-selrow'); }
    if(el){ el.classList.add('t3d-sel'); var r=el.closest?el.closest('.t3d-row'):null; if(r) r.classList.add('t3d-selrow');
      try{ el.focus(); }catch(e){}
      try{ var tgt=r||el, pr=panel.getBoundingClientRect(), er=tgt.getBoundingClientRect();  // scroll the panel directly
        if(er.bottom>pr.bottom-6) panel.scrollTop += (er.bottom-pr.bottom)+40;
        else if(er.top<pr.top+6) panel.scrollTop -= (pr.top-er.top)+40; }catch(e){} }
  }
  function resetDefaults(){
    for(var i=0;i<rowInputs.length;i++){ var ri=rowInputs[i];
      ri.inp.value=DEF[ri.key.replace('t3d_','')]; ri.inp.dispatchEvent(new Event('input',{bubbles:true})); }
  }
  function injectStyle(){
    var css=document.createElement('style'); css.id='t3d_style';
    css.textContent=
    "#t3d_panel{position:fixed;top:0;right:0;height:100%;width:380px;max-width:82vw;z-index:2147483601;"+
    "background:rgba(12,12,16,.98);border-left:2px solid #2a2a36;box-shadow:-12px 0 48px rgba(0,0,0,.7);"+
    "padding:12px 16px;display:none;flex-direction:column;gap:6px;color:#ececf0;overflow-y:auto;"+
    "font-family:-apple-system,Roboto,system-ui,sans-serif}"+
    "#t3d_panel h3{margin:0;font-size:18px}#t3d_panel .sub{color:#9a9aa6;font-size:11px;margin:-4px 0 2px}"+
    ".t3d-row{display:grid;grid-template-columns:84px 1fr 40px;align-items:center;gap:8px;font-size:12px}"+
    ".t3d-row input[type=range]{width:100%}.t3d-row .t3d-val{text-align:right;color:#9a9aa6}"+
    ".t3d-btn{background:#1d1d26;border:2px solid #2a2a36;color:#fff;font-weight:700;font-size:14px;padding:8px;border-radius:9px;cursor:pointer;text-align:center}"+
    ".t3d-btn.on{border-color:#00c85a;color:#00c85a}"+
    // JS-painted selection — does not rely on :focus (Shield/leanback override it)
    ".t3d-focusable.t3d-sel{border-color:#00c85a !important;background:#12351f !important;"+
    "box-shadow:0 0 0 3px rgba(0,200,90,.65) !important}"+
    ".t3d-row.t3d-selrow label{color:#00e06a !important;font-weight:700}"+
    ".t3d-row input[type=range].t3d-sel{outline:3px solid #00c85a;outline-offset:2px}";
    (document.head||document.documentElement).appendChild(css);
  }
  function mkRow(label,key,min,max,step,getv,setv){
    var row=document.createElement('div'); row.className='t3d-row';
    var l=document.createElement('label'); l.textContent=label;
    var val=document.createElement('span'); val.className='t3d-val'; val.textContent=getv();
    var inp=document.createElement('input'); inp.type='range'; inp.min=min; inp.max=max; inp.step=step;
    inp.value=getv(); inp.className='t3d-focusable'; inp.tabIndex=0;
    inp.addEventListener('input',function(){ setv(parseFloat(inp.value)); val.textContent=inp.value; save(key,inp.value); });
    rowInputs.push({key:key,inp:inp});
    row.appendChild(l); row.appendChild(inp); row.appendChild(val); return row;
  }
  function mkBtn(text,on,fn){ var b=document.createElement('div'); b.className='t3d-btn t3d-focusable'+(on?' on':'');
    b.tabIndex=0; b.textContent=text; b.addEventListener('click',fn); return b; }
  function buildPanel(){
    rowInputs=[];
    panel=document.createElement('div'); panel.id='t3d_panel';
    var h=document.createElement('h3'); h.textContent='3D Tube'; panel.appendChild(h);
    var sub=document.createElement('div'); sub.className='sub'; sub.textContent='green / magenta anaglyph'; panel.appendChild(sub);
    var b3=mkBtn(CFG.on?'3D: ON':'3D: OFF',CFG.on,function(){ CFG.on=!CFG.on; save('t3d_on',CFG.on?'1':'0');
      b3.textContent=CFG.on?'3D: ON':'3D: OFF'; b3.className='t3d-btn t3d-focusable'+(CFG.on?' on':''); }); panel.appendChild(b3);
    function modeLabel(){ return 'Mode: '+(CFG.mode? 'Red / Cyan':'Green / Magenta'); }
    var bm=mkBtn(modeLabel(),true,function(){ CFG.mode=CFG.mode?0:1; save('t3d_mode',CFG.mode?'1':'0');
      bm.textContent=modeLabel(); }); panel.appendChild(bm);
    var SRC=['2D (fake depth)','Side-by-Side','Top-Bottom','Auto'];
    function srcLabel(){ return 'Source: '+SRC[CFG.source]; }
    var bs=mkBtn(srcLabel(),true,function(){ CFG.source=(CFG.source+1)%4; save('t3d_source',CFG.source);
      bs.textContent=srcLabel(); }); panel.appendChild(bs);
    var bw=mkBtn('Swap L/R: '+(CFG.swap?'ON':'OFF'),CFG.swap,function(){ CFG.swap=!CFG.swap; save('t3d_swap',CFG.swap?'1':'0');
      bw.textContent='Swap L/R: '+(CFG.swap?'ON':'OFF'); bw.className='t3d-btn t3d-focusable'+(CFG.swap?' on':''); }); panel.appendChild(bw);
    panel.appendChild(mkRow('Depth','t3d_depth',0,60,1,function(){return CFG.depth;},function(v){CFG.depth=v;}));
    panel.appendChild(mkRow('Bright gain','t3d_green',0.5,1.0,0.01,function(){return CFG.green;},function(v){CFG.green=v;}));
    panel.appendChild(mkRow('Ghost fill','t3d_ghost',0,0.5,0.01,function(){return CFG.ghost;},function(v){CFG.ghost=v;}));
    panel.appendChild(mkRow('Desaturate','t3d_desat',0,0.7,0.01,function(){return CFG.desat;},function(v){CFG.desat=v;}));
    panel.appendChild(mkRow('Converge','t3d_converge',-0.01,0.01,0.001,function(){return CFG.converge;},function(v){CFG.converge=v;}));
    var adoff=false; try{ adoff=(window.NativeBridge&&NativeBridge.load('adoff')==='1'); }catch(e){}
    var bad=mkBtn('Ad blocker: '+(adoff?'OFF':'ON'), !adoff, function(){ adoff=!adoff;
      try{ if(window.NativeBridge){ NativeBridge.save('adoff',adoff?'1':'0'); if(NativeBridge.setAdOff) NativeBridge.setAdOff(adoff); } }catch(e){}
      bad.textContent='Ad blocker: '+(adoff?'OFF':'ON'); bad.className='t3d-btn t3d-focusable'+(adoff?'':' on'); });
    panel.appendChild(bad);
    panel.appendChild(mkBtn('Reset 3D to default',false,resetDefaults));
    var bbk=mkBtn('★  Bookmark this page',false,function(){ addBookmark(); bbk.textContent='★  Bookmarked'; });
    panel.appendChild(bbk);
    panel.appendChild(mkBtn('⌂  Home',false,function(){ location.href='https://t3d.home/'; }));
    panel.appendChild(mkBtn('Close',false,function(){ window.__t3dPanel(false); }));
    panel.style.display=panelOpen?'flex':'none';
    document.documentElement.appendChild(panel);
  }
  function isTV(){ try{ return !!(window.NativeBridge && NativeBridge.isTv()); }catch(e){ return true; } }
  function buildGear(){
    var g=document.createElement('div'); g.id='t3d_gear';
    g.style.cssText='position:fixed;z-index:2147483600;width:46px;height:46px;border-radius:50%;'+
      'background:rgba(18,18,26,.55);border:2px solid rgba(0,200,90,.75);color:#fff;'+
      'font:700 14px -apple-system,Roboto,system-ui,sans-serif;display:flex;align-items:center;justify-content:center;'+
      'cursor:pointer;opacity:.62;touch-action:none;transform:translate(-50%,-50%)';
    g.textContent='3D';
    function place(x,y){ g.style.left=x+'px'; g.style.top=y+'px'; }
    var pos=null; try{ pos=JSON.parse((window.NativeBridge&&NativeBridge.load('gearpos'))||'null'); }catch(e){}
    if(pos&&pos.x!=null) place(pos.x,pos.y); else place(innerWidth-30, innerHeight*0.5);
    var sx,sy,gx,gy,moved=false,drag=false;
    g.addEventListener('touchstart',function(e){ var t=e.touches[0]; sx=t.clientX; sy=t.clientY;
      gx=parseFloat(g.style.left); gy=parseFloat(g.style.top); moved=false; drag=true; e.stopPropagation(); },{passive:false});
    g.addEventListener('touchmove',function(e){ if(!drag)return; var t=e.touches[0]; var dx=t.clientX-sx,dy=t.clientY-sy;
      if(Math.abs(dx)+Math.abs(dy)>6) moved=true;
      place(Math.max(26,Math.min(innerWidth-26,gx+dx)), Math.max(26,Math.min(innerHeight-26,gy+dy)));
      e.preventDefault(); e.stopPropagation(); },{passive:false});
    g.addEventListener('touchend',function(e){ drag=false; e.stopPropagation();
      if(moved){ try{ NativeBridge.save('gearpos',JSON.stringify({x:parseFloat(g.style.left),y:parseFloat(g.style.top)})); }catch(e2){} }
      else { window.__t3dPanel(!panelOpen); } },{passive:false});
    g.addEventListener('click',function(e){ e.stopPropagation(); if(!('ontouchstart' in window)) window.__t3dPanel(!panelOpen); });
    document.documentElement.appendChild(g);
  }
  function ensureUI(){
    if(!document.getElementById('t3d_style')) injectStyle();
    var ex=document.getElementById('t3d_panel');
    if(!ex){ buildPanel(); } else { panel=ex; }
    if(!isTV() && !document.getElementById('t3d_gear')) buildGear();  // phones/tablets: touch trigger
  }

  /* ---------------- directional handling ---------------- */
  function dirOf(e){ var k=e.key,c=e.keyCode;
    if(k==='ArrowLeft'||c===37||c===21)return'left'; if(k==='ArrowRight'||c===39||c===22)return'right';
    if(k==='ArrowUp'||c===38||c===19)return'up'; if(k==='ArrowDown'||c===40||c===20)return'down'; return null; }
  function isOK(e){ var k=e.key,c=e.keyCode; return k==='Enter'||c===13||c===23||c===66; }
  function focusables(){ if(!panel) return [];
    return Array.prototype.slice.call(panel.querySelectorAll('.t3d-focusable')).filter(function(el){
      var r=el.getBoundingClientRect(); return r.width>4&&r.height>4; }); }
  function cen(el){ var r=el.getBoundingClientRect(); return {x:r.left+r.width/2,y:r.top+r.height/2}; }
  function move(dir){ var els=focusables(); if(!els.length) return; var cur=document.activeElement;
    if(els.indexOf(cur)<0){ selectEl(els[0]); return; }
    var a=cen(cur),best=null,bs=1e12;
    for(var i=0;i<els.length;i++){ if(els[i]===cur)continue; var p=cen(els[i]),dx=p.x-a.x,dy=p.y-a.y,ok=false,pri=0,cr=0;
      if(dir==='right'){ok=dx>8;pri=dx;cr=Math.abs(dy);} else if(dir==='left'){ok=dx<-8;pri=-dx;cr=Math.abs(dy);}
      else if(dir==='down'){ok=dy>8;pri=dy;cr=Math.abs(dx);} else if(dir==='up'){ok=dy<-8;pri=-dy;cr=Math.abs(dx);}
      if(!ok)continue; var sc=pri+cr*2.2; if(sc<bs){bs=sc;best=els[i];} }
    if(best) selectEl(best);
  }
  function handleDir(d){ var a=document.activeElement;
    if(a&&a.tagName==='INPUT'&&a.type==='range'&&(d==='left'||d==='right')){
      var st=parseFloat(a.step)||1,v=parseFloat(a.value)+(d==='right'?st:-st);
      v=Math.max(parseFloat(a.min),Math.min(parseFloat(a.max),v));
      a.value=v; a.dispatchEvent(new Event('input',{bubbles:true})); return; }
    move(d); }
  function activate(){ var a=document.activeElement; if(a&&a!==document.body&&a.click) a.click(); }

  // ---- D-pad cursor (browser mode; native calls these on non-YouTube pages) ----
  var cur=null,cx=0,cy=0;
  function cursorEl(){ if(!cur||!cur.isConnected){ cur=document.createElement('div'); cur.id='t3d_cursor';
      cur.style.cssText='position:fixed;width:26px;height:26px;border-radius:50%;z-index:2147483640;pointer-events:none;'+
        'background:rgba(255,255,255,.3);border:2px solid #00c85a;box-shadow:0 0 12px rgba(0,0,0,.7);transform:translate(-50%,-50%);display:none';
      document.documentElement.appendChild(cur); if(!cx&&!cy){ cx=innerWidth/2; cy=innerHeight/2; } } return cur; }
  function showCur(){ var c=cursorEl(); c.style.left=cx+'px'; c.style.top=cy+'px'; c.style.display='block'; }
  // scroll whatever scrollable container is under the cursor; fall back to the window
  function scrollUnder(dx,dy){
    var el=document.elementFromPoint(cx,cy);
    while(el && el!==document.body && el!==document.documentElement){
      try{ var cs=getComputedStyle(el);
        if((dy&&el.scrollHeight>el.clientHeight+2&&/auto|scroll/.test(cs.overflowY))||
           (dx&&el.scrollWidth>el.clientWidth+2&&/auto|scroll/.test(cs.overflowX))){ el.scrollLeft+=dx; el.scrollTop+=dy; return; }
      }catch(e){}
      el=el.parentElement;
    }
    scrollBy(dx,dy);
  }
  // constant-speed smooth cursor; auto-hides when idle
  var pressed={19:false,20:false,21:false,22:false}, canim=false, hideT=0;
  function scheduleHide(){ clearTimeout(hideT); hideT=setTimeout(function(){ if(cur) cur.style.display='none'; },3000); }
  function animCur(){
    var W=innerWidth, H=innerHeight, dx=0, dy=0;
    if(pressed[21])dx-=1; if(pressed[22])dx+=1; if(pressed[19])dy-=1; if(pressed[20])dy+=1;
    if(dx||dy){
      var sp=W*0.006; var L=Math.sqrt(dx*dx+dy*dy)||1; cx+=(dx/L)*sp; cy+=(dy/L)*sp;
      cx=Math.max(4,Math.min(W-4,cx)); cy=Math.max(4,Math.min(H-4,cy));
      var m=70; if(cy>H-m)scrollUnder(0,16); else if(cy<m)scrollUnder(0,-16);
      if(cx>W-m)scrollUnder(16,0); else if(cx<m)scrollUnder(-16,0);
      showCur(); requestAnimationFrame(animCur);
    } else { canim=false; scheduleHide(); }
  }
  window.__t3dCursor=function(kc){ if(pressed[kc]!==undefined) pressed[kc]=true; clearTimeout(hideT); showCur();
    if(!canim){ canim=true; requestAnimationFrame(animCur); } };
  window.__t3dCursorUp=function(kc){ if(pressed[kc]!==undefined) pressed[kc]=false; };
  window.__t3dClick=function(){
    showCur(); var el=document.elementFromPoint(cx,cy); if(!el) return;
    ['mouseover','mousedown','mouseup','click'].forEach(function(t){
      try{ el.dispatchEvent(new MouseEvent(t,{bubbles:true,cancelable:true,clientX:cx,clientY:cy,view:window})); }catch(e){} });
    try{ if(el.focus) el.focus(); }catch(e){}
    scheduleHide();
    // if it's a text field, ask the native side to pop the keyboard (WebView won't on its own)
    setTimeout(function(){ try{ var a=document.activeElement;
      if(a&&(a.isContentEditable||a.tagName==='INPUT'||a.tagName==='TEXTAREA')){
        if(window.NativeBridge&&NativeBridge.showKeyboard) NativeBridge.showKeyboard(); } }catch(e){} }, 60);
  };
  // Browser-mode Back: close an in-app player/overlay (Escape) if a video is up, else history back
  window.__t3dBackBrowser=function(){ try{
      // only intercept real fullscreen (exit it); otherwise normal history back
      if(document.fullscreenElement){ var o={key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true};
        var t=document.activeElement||document.body||document;
        t.dispatchEvent(new KeyboardEvent('keydown',o)); t.dispatchEvent(new KeyboardEvent('keyup',o));
        document.dispatchEvent(new KeyboardEvent('keydown',o));
        try{ if(document.exitFullscreen) document.exitFullscreen(); }catch(_){}
        return; }
      history.back();
    }catch(e){ try{history.back();}catch(_){} } };
  // ---- controls-reveal + hardware Back ----
  var controlsUntil=0;
  window.__t3dPoke=function(){ controlsUntil=Date.now()+4000; };
  window.__t3dBack=function(){ try{
      var o={key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true};
      var t=document.activeElement||document.body||document;
      t.dispatchEvent(new KeyboardEvent('keydown',o));
      t.dispatchEvent(new KeyboardEvent('keyup',o));
      window.dispatchEvent(new KeyboardEvent('keydown',o));
      document.dispatchEvent(new KeyboardEvent('keydown',o));
    }catch(e){} };
  // ---- history + bookmarks via the native bridge ----
  function recordHistory(){ try{ if(!window.NativeBridge) return; var u=location.href;
      if(!/^https?:/.test(u)) return;
      var a=[]; try{a=JSON.parse(NativeBridge.load('history')||'[]');}catch(e){}
      if(!(a.length&&a[0].u===u)){ a.unshift({u:u,t:(document.title||u).slice(0,120),d:Date.now()}); }
      if(a.length>120) a=a.slice(0,120); NativeBridge.save('history',JSON.stringify(a)); }catch(e){} }
  function addBookmark(){ try{ if(!window.NativeBridge) return; var u=location.href;
      if(!/^https?:/.test(u)) return;
      var a=[]; try{a=JSON.parse(NativeBridge.load('bookmarks')||'[]');}catch(e){}
      if(a.some(function(b){return b.u===u;})) return;
      a.push({u:u,t:(document.title||u).slice(0,60)}); NativeBridge.save('bookmarks',JSON.stringify(a)); }catch(e){} }

  // Driven by the native shell (which consumes the keys so leanback never sees them while open).
  window.__t3dKey=function(kc){ if(kc===23||kc===66){ activate(); return; }
    var d=kc===19?'up':kc===20?'down':kc===21?'left':kc===22?'right':null; if(d) handleDir(d); };
  window.__t3dPanel=function(open){ ensureUI(); if(open&&cur) cur.style.display='none'; panelOpen=!!open;
    try{ if(window.NativeBridge&&NativeBridge.setPanel) NativeBridge.setPanel(!!open); }catch(e){}
    if(panel){ panel.style.height=window.innerHeight+'px'; panel.style.display=panelOpen?'flex':'none'; }  // pin to real screen height so it scrolls
    if(panelOpen){ var f=panel&&panel.querySelector('.t3d-focusable'); if(f) selectEl(f); } };

  // keyboard/cursor fallback — only while open, so it never fights leanback
  window.addEventListener('keydown',function(e){ if(!panelOpen) return;
    var d=dirOf(e); if(d){ handleDir(d); e.preventDefault(); e.stopPropagation(); return; }
    if(isOK(e)){ activate(); e.preventDefault(); e.stopPropagation(); } },true);

  /* ---------------- boot ---------------- */
  function qnudge(){ try{ if(!/youtube/.test(location.hostname)) return;
      var p=document.getElementById('movie_player')||document.querySelector('.html5-video-player');
      if(!p) return;
      var top='highres';
      if(p.getAvailableQualityLevels){ var lv=p.getAvailableQualityLevels(); if(lv&&lv.length) top=lv[0]; } // [0] = highest (hd2160/4K, highres/8K)
      var curq=p.getPlaybackQuality?p.getPlaybackQuality():null;
      if(curq===top) return;   // already maxed — don't thrash the stream
      if(p.setPlaybackQualityRange) p.setPlaybackQualityRange(top,top);
      if(p.setPlaybackQuality) p.setPlaybackQuality(top);
    }catch(e){} }
  function boot(){ try{initGL();}catch(e){} try{ensureUI();}catch(e){}
    requestAnimationFrame(render); setInterval(adtick,150);
    setTimeout(recordHistory,800);
    try{ if(window.NativeBridge&&NativeBridge.setAdOff) NativeBridge.setAdOff(NativeBridge.load('adoff')==='1'); }catch(e){}
    [1500,3500,6000].forEach(function(t){ setTimeout(qnudge,t); }); setInterval(qnudge,5000);  // keep it at highest res across videos
    // touch devices: tapping reveals the real video controls briefly (hide 3D overlay)
    window.addEventListener('touchstart',function(){ if(Date.now()<controlsUntil) controlsUntil=Date.now()+4000; },true); }
  if(document.body) boot(); else document.addEventListener('DOMContentLoaded',boot);
})();
